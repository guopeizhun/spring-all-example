<template>
	<div>
		<beautiful-chat :participants="participants" :titleImageUrl="titleImageUrl" :onMessageWasSent="onMessageWasSent"
			:messageList="messageList" :newMessagesCount="newMessagesCount" :isOpen="isChatOpen" :close="closeChat"
			:icons="icons" :open="openChat" :showEmoji="true" :showFile="true" :showEdition="true" :showDeletion="true"
			:showTypingIndicator="showTypingIndicator" :showLauncher="true" :showCloseButton="true" :colors="colors"
			:alwaysScrollToBottom="alwaysScrollToBottom" :disableUserListToggle="false" :messageStyling="messageStyling"
			@onType="handleOnType" @edit="editMessage" />
		发送的用户id<input v-model="toId" />
		当前的用户id<input v-model="id" /><button @click="connect">连接</button>
	</div>

</template>

<script>
	// @ is an alias to /src
	import HelloWorld from '@/components/HelloWorld.vue'
	import SockJS from 'sockjs-client'
	import Stomp from 'stompjs'
	export default {
		name: 'HomeView',
		data() {
			return {
				id: '',
				msg: '',
				val: '',
				toId: '',
				stompClient: '',
				participants: [{
						id: 'user1',
						name: 'Matteo',
						imageUrl: 'https://avatars3.githubusercontent.com/u/1915989?s=230&v=4'
					},
					{
						id: 'me',
						name: 'Support',
						imageUrl: 'https://avatars3.githubusercontent.com/u/37018832?s=200&v=4'
					}
				], // 对话的所有参与者的列表。' name '是用户名，' id '用于建立消息的作者，' imageUrl '应该是用户头像。
				titleImageUrl: 'https://a.slack-edge.com/66f9/img/avatars-teams/ava_0001-34.png',
				messageList: [{
				// 		type: 'text',
				// 		author: `me`,
				// 		data: {
				// 			text: `Say yes!`
				// 		}
				// 	},
				// 	{
				// 		type: 'text',
				// 		author: `user1`,
				// 		data: {
				// 			text: `No.`
				// 		}
					}
				], // // 要显示的消息列表可以动态地分页和调整
				newMessagesCount: 0,
				isChatOpen: false, // 确定聊天窗口应该打开还是关闭
				showTypingIndicator: '', // 当设置为匹配参与者的值时。它显示特定用户的输入指示
				colors: {
					header: {
						bg: '#4e8cff',
						text: '#ffffff'
					},
					launcher: {
						bg: '#4e8cff'
					},
					messageList: {
						bg: '#ffffff'
					},
					sentMessage: {
						bg: '#4e8cff',
						text: '#ffffff'
					},
					receivedMessage: {
						bg: '#eaeaea',
						text: '#222222'
					},
					userInput: {
						bg: '#f4f7f9',
						text: '#565867'
					}
				}, // specifies the color scheme for the component
				alwaysScrollToBottom: false, // 当设置为true时，当有新事件发生时(新消息，用户开始输入…)，总是将聊天滚动到底部。
				messageStyling: true // 启用*bold* /emph/ _underline_等(更多信息请访问github.com/mattezza/msgdown)

			}
		},
		methods: {
			connect() {
				var sockJs = new SockJS("http://localhost:9000/ws");
				var stompClient = Stomp.over(sockJs);
				this.stompClient = stompClient
				var id = this.id
				var toId = this.toId
				var that = this
				stompClient.connect({}, function(data) {
					var that1 = that
					alert("连接成功")
					stompClient.subscribe("/user/"+toId+"/message/get/"+id, function(response) {
						var arr = response.body.split("$")
						var data = {}
						if(arr[1] == 'text'){
							data = {
								text: arr[0]
							}
						}else{
							data = {
								emoji: arr[0]
							}
						}
						let message = {
						type: arr[1],
						author: id,
						data
						
					}
						that.messageList = [...that.messageList,message]
					})
				})
			},
			send() {
				var stompClient = this.stompClient
				var sendid = this.id;
				var toId = this.toId
				var message = this.msg
				stompClient.send("/welcome", {}, "欢迎" + sendid + "来到直播间");

			},
			sendMessage(text) {
				if (text.length > 0) {
					this.newMessagesCount = this.isChatOpen ? this.newMessagesCount : this.newMessagesCount + 1
					this.onMessageWasSent({
						author: 'support',
						type: 'text',
						data: {
							text
						}
					})
				}
			},
			onMessageWasSent(message) {
				
				// 当用户发送消息时调用
				this.stompClient.send("/message", {}, JSON.stringify({
					fromUser:this.id,
					toUser:this.toId,
					msg:message.data.text || message.data.emoji,
					type:message.type
				}));
				this.messageList = [...this.messageList, message]
			},
			openChat() {
				// 当用户单击fab按钮打开聊天时调用
				this.isChatOpen = true
				this.newMessagesCount = 0
			},
			closeChat() {
				// // 当用户单击按钮关闭聊天时调用
				this.isChatOpen = false
			},
			handleScrollToTop() {

				// 当用户将消息列表滚动到顶部时调用
				// 利用分页来加载另一个消息页面

			},
			handleOnType() {
				console.log('Emit typing event')
			},
			editMessage(message) {
				const m = this.messageList.find(m => m.id === message.id);
				m.isEdited = true;
				m.data.text = message.data.text;
			}

		},

		components: {
			HelloWorld
		}
	}
</script>
